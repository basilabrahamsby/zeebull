﻿from sqlalchemy.orm import Session, joinedload, selectinload
from sqlalchemy import func
from decimal import Decimal
from datetime import datetime
from typing import Optional, List
from fastapi import HTTPException
from app.models.inventory import (
    InventoryCategory, InventoryItem, Vendor, PurchaseMaster, PurchaseDetail, InventoryTransaction,
    StockRequisition, StockRequisitionDetail, StockIssue, StockIssueDetail, WasteLog, Location, AssetMapping
)
from app.schemas.inventory import (
    InventoryCategoryCreate, InventoryCategoryUpdate, InventoryItemCreate, InventoryItemUpdate, VendorCreate, PurchaseMasterCreate, PurchaseMasterUpdate,
    StockRequisitionCreate, StockRequisitionUpdate, StockIssueCreate
)


# Category CRUD
def create_category(db: Session, data: InventoryCategoryCreate):
    category = InventoryCategory(**data.dict())
    db.add(category)
    db.commit()
    db.refresh(category)
    return category


def get_all_categories(db: Session, skip: int = 0, limit: int = 100, active_only: bool = True):
    query = db.query(InventoryCategory)
    if active_only:
        query = query.filter(InventoryCategory.is_active == True)
    return query.offset(skip).limit(limit).all()


def get_category_by_id(db: Session, category_id: int):
    return db.query(InventoryCategory).filter(InventoryCategory.id == category_id).first()


def update_category(db: Session, category_id: int, data: InventoryCategoryUpdate):
    category = get_category_by_id(db, category_id)
    if not category:
        return None
    
    for field, value in data.dict(exclude_unset=True).items():
        setattr(category, field, value)
    
    db.commit()
    db.refresh(category)
    return category


# Item CRUD
def create_item(db: Session, data: InventoryItemCreate):
    item = InventoryItem(**data.dict())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def get_all_items(db: Session, skip: int = 0, limit: int = 100, category_id: Optional[int] = None, active_only: bool = True):
    """Optimized with eager loading to prevent N+1 queries"""
    query = db.query(InventoryItem).options(
        joinedload(InventoryItem.category),
        joinedload(InventoryItem.preferred_vendor)
    )
    if category_id:
        query = query.filter(InventoryItem.category_id == category_id)
    if active_only:
        query = query.filter(InventoryItem.is_active == True)
    return query.offset(skip).limit(limit).all()


def get_item_by_id(db: Session, item_id: int):
    return db.query(InventoryItem).filter(InventoryItem.id == item_id).first()


def update_item(db: Session, item_id: int, data: InventoryItemUpdate):
    item = get_item_by_id(db, item_id)
    if not item:
        return None
    
    for field, value in data.dict(exclude_unset=True).items():
        if value is not None:
            setattr(item, field, value)
    
    db.commit()
    db.refresh(item)
    return item


def update_item_stock(db: Session, item_id: int, quantity_change: float, transaction_type: str):
    """Update item stock and create transaction record"""
    item = get_item_by_id(db, item_id)
    if not item:
        return None
    
    if transaction_type == "in":
        item.current_stock += quantity_change
    elif transaction_type == "out":
        item.current_stock -= quantity_change
    elif transaction_type == "adjustment":
        item.current_stock = quantity_change
    
    db.commit()
    db.refresh(item)
    return item


# Vendor CRUD
def create_vendor(db: Session, data: VendorCreate):
    vendor = Vendor(**data.model_dump())
    db.add(vendor)
    db.commit()
    db.refresh(vendor)
    return vendor


def get_all_vendors(db: Session, skip: int = 0, limit: int = 100, active_only: bool = False):
    query = db.query(Vendor)
    if active_only:
        query = query.filter(Vendor.is_active == True)
    return query.offset(skip).limit(limit).all()


def get_vendor_by_id(db: Session, vendor_id: int):
    return db.query(Vendor).filter(Vendor.id == vendor_id).first()

def get_vendors_by_ids(db: Session, vendor_ids: List[int]):
    """Batch load vendors by IDs to avoid N+1 queries"""
    if not vendor_ids:
        return []
    return db.query(Vendor).filter(Vendor.id.in_(vendor_ids)).all()


# Purchase Master CRUD
def generate_purchase_number(db: Session):
    """Generate unique purchase number based on latest sequence"""
    today_str = datetime.now().strftime('%Y%m%d')
    prefix = f"PO-{today_str}-"
    
    last_entry = db.query(PurchaseMaster).filter(
        PurchaseMaster.purchase_number.like(f"{prefix}%")
    ).order_by(PurchaseMaster.id.desc()).first()

    if last_entry and last_entry.purchase_number:
        try:
            parts = last_entry.purchase_number.split('-')
            last_seq = int(parts[-1])
            return f"{prefix}{last_seq + 1:04d}"
        except (ValueError, IndexError):
            pass
            
    return f"{prefix}0001"


def calculate_gst(amount: Decimal, gst_rate: Decimal, is_interstate: bool = False):
    """Calculate CGST, SGST, or IGST based on interstate status"""
    gst_amount = (amount * gst_rate) / Decimal("100")
    if is_interstate:
        return Decimal("0.00"), Decimal("0.00"), gst_amount
    else:
        # Split GST equally between CGST and SGST
        half_gst = gst_amount / Decimal("2")
        return half_gst, half_gst, Decimal("0.00")


def create_purchase_master(db: Session, data: PurchaseMasterCreate, created_by: int = None):
    """Create purchase master with details and calculate totals"""
    # Generate purchase number if not provided
    if not data.purchase_number:
        data.purchase_number = generate_purchase_number(db)
    
    # Get vendor to check if interstate (different state)
    vendor = get_vendor_by_id(db, data.vendor_id)
    is_interstate = False  # Default, can be enhanced with user state
    
    # Calculate totals from details
    sub_total = Decimal("0.00")
    total_cgst = Decimal("0.00")
    total_sgst = Decimal("0.00")
    total_igst = Decimal("0.00")
    total_discount = Decimal("0.00")
    
    # Create purchase master
    master_data = data.dict(exclude={"details"})
    purchase_master = PurchaseMaster(**master_data, created_by=created_by)
    db.add(purchase_master)
    db.flush()  # Get the ID
    
    # Create purchase details and calculate totals
    for detail_data in data.details:
        item = get_item_by_id(db, detail_data.item_id)
        if not item:
            continue
        
        # Use item's HSN if not provided in detail
        hsn_code = detail_data.hsn_code or item.hsn_code
        
        # Calculate line total before GST
        line_total = (Decimal(str(detail_data.quantity)) * Decimal(str(detail_data.unit_price))) - Decimal(str(detail_data.discount))
        
        # Calculate GST
        cgst, sgst, igst = calculate_gst(line_total, Decimal(str(detail_data.gst_rate)), is_interstate)
        line_total_with_gst = line_total + cgst + sgst + igst
        
        # Create purchase detail
        purchase_detail = PurchaseDetail(
            purchase_master_id=purchase_master.id,
            item_id=detail_data.item_id,
            hsn_code=hsn_code,
            quantity=detail_data.quantity,
            unit=detail_data.unit,
            unit_price=Decimal(str(detail_data.unit_price)),
            gst_rate=Decimal(str(detail_data.gst_rate)),
            cgst_amount=cgst,
            sgst_amount=sgst,
            igst_amount=igst,
            discount=Decimal(str(detail_data.discount)),
            total_amount=line_total_with_gst,
            notes=detail_data.notes
        )
        db.add(purchase_detail)
        
        # Accumulate totals
        sub_total += line_total
        total_cgst += cgst
        total_sgst += sgst
        total_igst += igst
        total_discount += Decimal(str(detail_data.discount))
    
    # Update master totals
    purchase_master.sub_total = sub_total
    purchase_master.cgst = total_cgst
    purchase_master.sgst = total_sgst
    purchase_master.igst = total_igst
    purchase_master.discount = total_discount
    purchase_master.total_amount = sub_total + total_cgst + total_sgst + total_igst - total_discount
    
    # Logic for inventory update is handled in API layer to support LocationStock and Weighted Average Cost
    # calling simple update_item_stock here would miss LocationStock and cause double counting if API also runs.
    
    db.commit()
    db.refresh(purchase_master)
    return purchase_master


def get_all_purchases(db: Session, skip: int = 0, limit: int = 100, status: Optional[str] = None):
    """Optimized with eager loading"""
    query = db.query(PurchaseMaster).options(
        joinedload(PurchaseMaster.vendor),
        selectinload(PurchaseMaster.details).joinedload(PurchaseDetail.item)
    )
    if status:
        query = query.filter(PurchaseMaster.status == status)
    return query.order_by(PurchaseMaster.created_at.desc()).offset(skip).limit(limit).all()


def get_purchase_by_id(db: Session, purchase_id: int):
    return db.query(PurchaseMaster).filter(PurchaseMaster.id == purchase_id).first()



def get_item_stocks(db: Session, item_id: int):
    """Fetch all location stocks for a specific item"""
    from app.models.inventory import LocationStock, Location
    
    stocks = db.query(LocationStock).join(Location).filter(
        LocationStock.item_id == item_id,
        LocationStock.quantity > 0
    ).all()
    
    result = []
    for s in stocks:
        result.append({
            "location_id": s.location.id,
            "location_name": s.location.name,
            "location_type": s.location.location_type,
            "quantity": float(s.quantity)
        })
    return result


def update_purchase_master(db: Session, purchase_id: int, data: PurchaseMasterUpdate):
    purchase = get_purchase_by_id(db, purchase_id)
    if not purchase:
        return None
    
    # Only allow updates if status is not received or cancelled
    if purchase.status in ["received", "cancelled"] and data.status != "cancelled":
        # If trying to update other fields but not cancelling, restrict it
        # But if just updating payment status, allow it
        allowed_fields = ["payment_status", "payment_terms", "notes"]
        update_data = data.dict(exclude_unset=True)
        if any(field not in allowed_fields for field in update_data.keys()):
             return None # Or raise error in API
    
    for field, value in data.dict(exclude_unset=True, exclude={"details"}).items():
        setattr(purchase, field, value)
    
    # Handle details update if provided
    if data.details is not None:
        # Delete existing details
        db.query(PurchaseDetail).filter(PurchaseDetail.purchase_master_id == purchase.id).delete()
        
        # Reset totals
        sub_total = Decimal("0.00")
        total_cgst = Decimal("0.00")
        total_sgst = Decimal("0.00")
        total_igst = Decimal("0.00")
        total_discount = Decimal("0.00")
        
        # Check if interstate (based on current vendor)
        vendor = get_vendor_by_id(db, purchase.vendor_id)
        is_interstate = False
        # Logic to determine interstate (simplified)
        # In a real app, compare vendor state with company state
        
        for detail_data in data.details:
            item = get_item_by_id(db, detail_data.item_id)
            if not item:
                continue
            
            hsn_code = detail_data.hsn_code or item.hsn_code
            
            # Calculate line total before GST
            line_total = (Decimal(str(detail_data.quantity)) * Decimal(str(detail_data.unit_price))) - Decimal(str(detail_data.discount))
            
            # Calculate GST
            cgst, sgst, igst = calculate_gst(line_total, Decimal(str(detail_data.gst_rate)), is_interstate)
            line_total_with_gst = line_total + cgst + sgst + igst
            
            # Create purchase detail
            purchase_detail = PurchaseDetail(
                purchase_master_id=purchase.id,
                item_id=detail_data.item_id,
                hsn_code=hsn_code,
                quantity=detail_data.quantity,
                unit=detail_data.unit,
                unit_price=Decimal(str(detail_data.unit_price)),
                gst_rate=Decimal(str(detail_data.gst_rate)),
                cgst_amount=cgst,
                sgst_amount=sgst,
                igst_amount=igst,
                discount=Decimal(str(detail_data.discount)),
                total_amount=line_total_with_gst,
                notes=detail_data.notes
            )
            db.add(purchase_detail)
            
            # Accumulate totals
            sub_total += line_total
            total_cgst += cgst
            total_sgst += sgst
            total_igst += igst
            total_discount += Decimal(str(detail_data.discount))
        
        # Update master totals
        purchase.sub_total = sub_total
        purchase.cgst = total_cgst
        purchase.sgst = total_sgst
        purchase.igst = total_igst
        purchase.discount = total_discount
        purchase.total_amount = sub_total + total_cgst + total_sgst + total_igst - total_discount
    
    db.commit()
    db.refresh(purchase)
    return purchase


def update_purchase_status(db: Session, purchase_id: int, status: str):
    """Update purchase status and handle inventory if received"""
    purchase = get_purchase_by_id(db, purchase_id)
    if not purchase:
        return None
    
    old_status = purchase.status
    purchase.status = status
    
    
    # If changing to received, update inventory
    if old_status.lower() != "received" and status.lower() == "received":
        from datetime import datetime
        from app.models.inventory import LocationStock, InventoryTransaction
        
        for detail in purchase.details:
            # Update global stock
            update_item_stock(db, detail.item_id, detail.quantity, "in")
            
            # CRITICAL FIX: Update destination location stock
            if purchase.destination_location_id:
                loc_stock = db.query(LocationStock).filter(
                    LocationStock.location_id == purchase.destination_location_id,
                    LocationStock.item_id == detail.item_id
                ).first()
                
                if loc_stock:
                    loc_stock.quantity += detail.quantity
                    loc_stock.last_updated = datetime.utcnow()
                else:
                    loc_stock = LocationStock(
                        location_id=purchase.destination_location_id,
                        item_id=detail.item_id,
                        quantity=detail.quantity,
                        last_updated=datetime.utcnow()
                    )
                    db.add(loc_stock)
            
            # Create transaction if not exists
            existing_transaction = db.query(InventoryTransaction).filter(
                InventoryTransaction.purchase_master_id == purchase_id,
                InventoryTransaction.item_id == detail.item_id
            ).first()
            if not existing_transaction:
                transaction = InventoryTransaction(
                    item_id=detail.item_id,
                    transaction_type="in",
                    quantity=detail.quantity,
                    unit_price=float(detail.unit_price),
                    total_amount=float(detail.total_amount),
                    reference_number=purchase.purchase_number,
                    purchase_master_id=purchase.id,
                    notes=f"Purchase: {purchase.purchase_number}",
                    created_by=purchase.created_by
                )
                db.add(transaction)
    
    db.commit()
    db.refresh(purchase)
    return purchase


# Stock Requisition CRUD
def generate_requisition_number(db: Session):
    from datetime import datetime
    today = datetime.utcnow()
    date_str = today.strftime("%Y%m%d")
    count = db.query(StockRequisition).filter(
        StockRequisition.requisition_number.like(f"REQ-{date_str}-%")
    ).count() + 1
    return f"REQ-{date_str}-{str(count).zfill(3)}"  # e.g., REQ-101


def create_stock_requisition(db: Session, data: dict, created_by: int):
    from app.models.inventory import StockRequisition, StockRequisitionDetail
    from datetime import datetime
    
    requisition_number = generate_requisition_number(db)
    requisition = StockRequisition(
        requisition_number=requisition_number,
        requested_by=created_by,
        destination_department=data["destination_department"],
        date_needed=data.get("date_needed"),
        priority=data.get("priority", "normal"),
        status="pending",
        notes=data.get("notes"),
    )
    db.add(requisition)
    db.flush()
    
    for detail_data in data["details"]:
        detail = StockRequisitionDetail(
            requisition_id=requisition.id,
            item_id=detail_data["item_id"],
            requested_quantity=detail_data["requested_quantity"],
            approved_quantity=detail_data.get("approved_quantity"),
            unit=detail_data["unit"],
            notes=detail_data.get("notes"),
        )
        db.add(detail)
    
    db.commit()
    db.refresh(requisition)
    return requisition


def get_all_requisitions(db: Session, skip: int = 0, limit: int = 100, status: Optional[str] = None):
    """Optimized with eager loading"""
    from app.models.inventory import StockRequisition
    query = db.query(StockRequisition).options(
        selectinload(StockRequisition.details).joinedload(StockRequisitionDetail.item)
    )
    if status:
        query = query.filter(StockRequisition.status == status)
    return query.order_by(StockRequisition.created_at.desc()).offset(skip).limit(limit).all()


def get_requisition_by_id(db: Session, requisition_id: int):
    from app.models.inventory import StockRequisition
    return db.query(StockRequisition).filter(StockRequisition.id == requisition_id).first()


def update_requisition_status(db: Session, requisition_id: int, status: str, approved_by: Optional[int] = None):
    from app.models.inventory import StockRequisition
    from datetime import datetime
    
    requisition = get_requisition_by_id(db, requisition_id)
    if not requisition:
        return None
    
    requisition.status = status
    if status == "approved" and approved_by:
        requisition.approved_by = approved_by
        requisition.approved_at = datetime.utcnow()
    
    db.commit()
    db.refresh(requisition)
    return requisition


# Stock Issue CRUD
def generate_issue_number(db: Session):
    from datetime import datetime
    from app.models.inventory import StockIssue
    
    today = datetime.utcnow()
    date_str = today.strftime("%Y%m%d")
    
    # Get the last issue number for today to continue sequence
    last_issue = db.query(StockIssue).filter(
        StockIssue.issue_number.like(f"ISS-{date_str}-%")
    ).order_by(StockIssue.issue_number.desc()).first()
    
    start_suffix = 1
    if last_issue:
        try:
            parts = last_issue.issue_number.split('-')
            # Assuming format ISS-YYYYMMDD-XXX
            if len(parts) >= 3:
                start_suffix = int(parts[-1]) + 1
        except:
             pass
             
    # Fallback to count if parsing failed or no previous (but maybe count logic is useful if sequence broken? 
    # Actually, using count alone is what caused the bug. Trusting sequence from DB max is better)
    if start_suffix == 1 and not last_issue:
         count = db.query(StockIssue).filter(
            StockIssue.issue_number.like(f"ISS-{date_str}-%")
         ).count()
         if count > 0:
            start_suffix = count + 1

    # Safety Check Loop to ensure uniqueness
    loop_count = 0
    while True:
        loop_count += 1
        candidate = f"ISS-{date_str}-{str(start_suffix).zfill(3)}"
        
        exists = db.query(StockIssue).filter(StockIssue.issue_number == candidate).count()
        if exists == 0:
            return candidate
            
        start_suffix += 1
        if loop_count > 1000:
             print(f"WARNING: generate_issue_number looped 1000 times. Returning risky candidate: {candidate}")
             return candidate


def create_stock_issue(db: Session, data: dict, issued_by: int):
    from app.models.inventory import StockIssue, StockIssueDetail, InventoryTransaction, InventoryItem, Location, LocationStock
    from datetime import datetime
    
    issue_number = generate_issue_number(db)
    
    # Parse issue_date if provided as string
    issue_date = data.get("issue_date")
    if issue_date and isinstance(issue_date, str):
        try:
            issue_date = datetime.fromisoformat(issue_date.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            issue_date = datetime.utcnow()
    elif not issue_date:
        issue_date = datetime.utcnow()
    
    issue = StockIssue(
        issue_number=issue_number,
        requisition_id=data.get("requisition_id"),
        issued_by=issued_by,
        source_location_id=data.get("source_location_id"),
        destination_location_id=data.get("destination_location_id"),
        issue_date=issue_date,
        notes=data.get("notes"),
    )
    db.add(issue)
    db.flush()
    
    for detail_data in data["details"]:
        item = get_item_by_id(db, detail_data["item_id"])
        if not item:
            continue
        
        # Check stock availability
        issued_qty = detail_data.get("issued_quantity", detail_data.get("quantity", 0))
        if issued_qty <= 0:
            continue  # Skip zero or negative quantities
        
        # SMART SOURCE LOCATION DETECTION
        # If no source specified, find which non-guest-room location actually has this item
        source_loc_id = data.get("source_location_id")
        if not source_loc_id:
            from app.models.inventory import LocationStock
            # Find locations that have this item (excluding guest rooms)
            available_locations = db.query(LocationStock).join(Location).filter(
                LocationStock.item_id == detail_data["item_id"],
                LocationStock.quantity >= issued_qty,
                Location.location_type != "GUEST_ROOM"
            ).order_by(LocationStock.quantity.desc()).all()
            
            if available_locations:
                # Use the location with most stock
                source_loc_id = available_locations[0].location_id
                source_loc_name = available_locations[0].location.name if available_locations[0].location else f"Location {source_loc_id}"
                print(f"[AUTO-DETECT] Item {item.name}: Using {source_loc_name} (ID: {source_loc_id}) as source (has {available_locations[0].quantity} units)")
                # Update the issue record's source if this is the first item
                if not issue.source_location_id:
                    issue.source_location_id = source_loc_id
            else:
                # Fallback: try to find ANY warehouse/store
                warehouse = db.query(Location).filter(
                    Location.location_type.in_(["WAREHOUSE", "CENTRAL_WAREHOUSE", "BRANCH_STORE", "DEPARTMENT", "LAUNDRY"])
                ).first()
                if warehouse:
                    source_loc_id = warehouse.id
                    if not issue.source_location_id:
                        issue.source_location_id = source_loc_id
        
        # Strict Stock Check
        # Check against Source Location Stock if specified (preferred for allocations)
        if source_loc_id:
             from app.models.inventory import LocationStock
             source_stock_record = db.query(LocationStock).filter(
                 LocationStock.location_id == source_loc_id,
                 LocationStock.item_id == detail_data["item_id"]
             ).first()
             
             available_qty = source_stock_record.quantity if source_stock_record else 0.0
             
             # Fallback: If location stock is insufficient BUT global stock is sufficient,
             # we DO NOT allow it anymore to prevent negative stock at location level.
             if available_qty < issued_qty:
                 print(f"[WARNING] Insufficient stock at source location for {item.name}. Available: {available_qty}, Requested: {issued_qty}. Proceeding anyway.")
                 # raise HTTPException(status_code=400, detail=f"Insufficient stock at source location for {item.name}. Available: {available_qty}, Requested: {issued_qty}")
        else:
             # Fallback to global stock check if no source specified
             if item.current_stock < issued_qty:
                 raise HTTPException(status_code=400, detail=f"Insufficient Global Stock for {item.name}. Available: {item.current_stock}, Requested: {issued_qty}.")
        
        # Calculate cost/price
        # Ensure float arithmetic
        # USE SELLING PRICE PREFERENCE for Guest Room issues (or generally if defined)
        price_to_use = item.unit_price # Default to cost
        if item.selling_price and item.selling_price > 0:
             price_to_use = item.selling_price
        
        u_price = float(price_to_use or 0)
        i_qty = float(issued_qty or 0)
        cost = u_price * i_qty
        
        # Use is_payable from request if provided (frontend sends this), otherwise default to False
        is_payable = detail_data.get("is_payable", False)
        print(f"[DEBUG] Item {item.name}: is_payable from request = {is_payable}, detail_data = {detail_data}")
        
        # Create issue detail
        detail = StockIssueDetail(
            issue_id=issue.id,
            item_id=detail_data["item_id"],
            issued_quantity=i_qty,
            batch_lot_number=detail_data.get("batch_lot_number"),
            unit=detail_data["unit"],
            unit_price=u_price,
            cost=cost,
            notes=detail_data.get("notes"),
            is_payable=is_payable,
            rental_price=detail_data.get("rental_price"),
        )
        db.add(detail)
        
        # Get destination location for determining if this is a transfer or consumption
        # CRITICAL FIX: Check destination_location_id directly, not just the fetched object
        dest_location_id = data.get("destination_location_id")
        dest_location = None
        if dest_location_id:
            dest_location = get_location_by_id(db, dest_location_id)
        
        # CRITICAL FIX: Only deduct global stock if this is actual consumption (no destination)
        # If there's a destination, it's a transfer - stock still exists, just moved locations
        if not dest_location_id:
            # Actual consumption - deduct from global stock
            print(f"[STOCK] Consumption: Deducting {issued_qty} of {item.name} from global stock")
            item.current_stock -= issued_qty
        else:
            # Transfer between locations - global stock unchanged (just location stocks change)
            print(f"[STOCK] Transfer: Moving {issued_qty} of {item.name} between locations (global stock unchanged)")
        
        dest_location_name = ""
        if dest_location:
            dest_location_name = f"{dest_location.building} - {dest_location.room_area}" if dest_location.building or dest_location.room_area else dest_location.name or f"Location {dest_location.id}"
        
        # Create transaction record with destination location info
        transaction_notes = f"Stock Issue: {issue_number}"
        if dest_location_name:
            transaction_notes += f" → {dest_location_name}"
        if data.get('notes'):
            transaction_notes += f" - {data.get('notes', '')}"
        
        # Determine transaction type based on whether this is a transfer or consumption
        # If there's a destination location, it's a transfer (stock still exists)
        # If no destination, it's actual consumption (stock is used up)
        out_transaction_type = "transfer_out" if dest_location else "out"
        
        # OUT transaction (from source/global inventory)
        transaction_out = InventoryTransaction(
            item_id=detail_data["item_id"],
            transaction_type=out_transaction_type,
            quantity=i_qty,
            unit_price=u_price,
            total_amount=cost,
            reference_number=issue_number,
            notes=transaction_notes,
            created_by=issued_by
        )
        db.add(transaction_out)
        
        # IN transaction (to destination location) - shows as "Stock Received" at destination
        if dest_location:
            transaction_in = InventoryTransaction(
                item_id=detail_data["item_id"],
                transaction_type="transfer_in",
                quantity=i_qty,
                unit_price=u_price,
                total_amount=cost,
                reference_number=issue_number,
                notes=f"Stock Received: {issue_number} from {data.get('source_location_id', 'Central')}",
                created_by=issued_by,
                department=dest_location_name  # Track which location received it
            )
            db.add(transaction_in)
        
        # Create Journal Entry for Consumption (COGS)
        # ONLY if this is actual consumption (no destination location)
        # If there's a destination, it's just a transfer - inventory still exists
        # We also check data.get("destination_location_id") to be safe in case object lookup failed
        if cost and cost > 0 and not dest_location and not data.get("destination_location_id"):
            try:
                from app.utils.accounting_helpers import create_consumption_journal_entry
                create_consumption_journal_entry(
                    db=db,
                    consumption_id=issue.id,
                    cogs_amount=float(cost),
                    inventory_item_name=item.name,
                    created_by=issued_by
                )
            except Exception as e:
                print(f"[WARNING] Could not create consumption journal entry: {e}")
        
        # Update requisition status if linked
        if data.get("requisition_id"):
            update_requisition_status(db, data["requisition_id"], "issued")

        # Update Destination Location Stock
        # This ensures the item appears in the room's inventory list
        dest_loc_id = data.get("destination_location_id")
        if dest_loc_id:
             from app.models.inventory import LocationStock
             
             loc_stock = db.query(LocationStock).filter(
                 LocationStock.location_id == dest_loc_id,
                 LocationStock.item_id == detail_data["item_id"]
             ).first()
             
             if loc_stock:
                 loc_stock.quantity += i_qty
                 loc_stock.last_updated = datetime.utcnow()
             else:
                 new_stock = LocationStock(
                     location_id=dest_loc_id,
                     item_id=detail_data["item_id"],
                     quantity=i_qty,
                     last_updated=datetime.utcnow()
                 )
                 db.add(new_stock)

        # Update Source Location Stock (Deduct)
        if source_loc_id:
             from app.models.inventory import LocationStock
             
             source_stock = db.query(LocationStock).filter(
                 LocationStock.location_id == source_loc_id,
                 LocationStock.item_id == detail_data["item_id"]
             ).first()
             
             if source_stock:
                 source_stock.quantity -= i_qty
                 # If negative, we allowed it via fallback, so just track it.
             else:
                 # If source stock record didn't exist but we allowed it (Fallback logic),
                 # we should Create it with negative value (or 0) to track the gap?
                 # Or if Global had it, maybe we just assume it was there.
                 # Let's create it with quantity = -issued_qty (or 0 if we assume it was unrecorded positive)
                 # Actually, if we assume it was there but unrecorded, setting to 0 is safer than negative.
                 # BUT, for accounting, let's set it to 0 (assuming we just consumed the unrecorded stock).
                 # Wait, if we want to be strict, we'd say -i_qty.
                 # Let's init at 0 and subtract.
                 new_source_stock = LocationStock(
                     location_id=source_loc_id,
                     item_id=detail_data["item_id"],
                     quantity= -i_qty if i_qty > 0 else 0, # Initialize negative if we believe we owe it
                     last_updated=datetime.utcnow()
                 )
                 db.add(new_source_stock)
    
    db.commit()
    db.refresh(issue)
    return issue


def get_all_issues(db: Session, skip: int = 0, limit: int = 100):
    """Optimized with eager loading"""
    from app.models.inventory import StockIssue
    return db.query(StockIssue).options(
        joinedload(StockIssue.source_location),
        joinedload(StockIssue.destination_location),
        selectinload(StockIssue.details).joinedload(StockIssueDetail.item)
    ).order_by(StockIssue.created_at.desc()).offset(skip).limit(limit).all()


def get_issue_by_id(db: Session, issue_id: int):
    from app.models.inventory import StockIssue
    return db.query(StockIssue).filter(StockIssue.id == issue_id).first()


# Waste Log CRUD
def generate_waste_log_number(db: Session):
    from datetime import datetime
    from app.models.inventory import WasteLog
    today = datetime.utcnow()
    date_str = today.strftime("%Y%m%d")
    
    # Get the last log number for today
    last_log = db.query(WasteLog).filter(
        WasteLog.log_number.like(f"WASTE-{date_str}-%")
    ).order_by(WasteLog.log_number.desc()).first()
    
    start_suffix = 1
    if last_log:
        try:
            parts = last_log.log_number.split('-')
            start_suffix = int(parts[-1]) + 1
        except:
             count = db.query(WasteLog).filter(
                WasteLog.log_number.like(f"WASTE-{date_str}-%")
             ).count() + 1
             start_suffix = count
    
    # Safety Check Loop
    # Safety Check Loop
    loop_count = 0
    while True:
        loop_count += 1
        candidate = f"WASTE-{date_str}-{str(start_suffix).zfill(3)}"
        
        exists = db.query(WasteLog).filter(WasteLog.log_number == candidate).count()
        if exists == 0:
            return candidate
            
        start_suffix += 1
        if loop_count > 1000:
             # Failsafe - should practically never happen if start_suffix is correct
             print(f"WARNING: generate_waste_log_number looped 1000 times. Returning risky candidate: {candidate}")
             return candidate


def create_waste_log(db: Session, data: dict, reported_by: int):
    from app.models.inventory import WasteLog, InventoryTransaction, InventoryItem
    from app.models.food_item import FoodItem
    from datetime import datetime
    
    is_food = data.get("is_food_item", False)
    
    if is_food:
        food_item_id = data.get("food_item_id")
        if not food_item_id:
            raise ValueError("Food item ID is required for food waste")
        
        food_item = db.query(FoodItem).filter(FoodItem.id == food_item_id).first()
        if not food_item:
            raise ValueError("Food item not found")
        
        log_number = generate_waste_log_number(db)
        waste_log = WasteLog(
            log_number=log_number,
            food_item_id=food_item_id,
            is_food_item=True,
            location_id=data.get("location_id"),
            quantity=data["quantity"],
            unit=data["unit"],
            reason_code=data["reason_code"],
            action_taken=data.get("action_taken"),
            photo_path=data.get("photo_path"),
            notes=data.get("notes"),
            reported_by=reported_by,
            waste_date=data.get("waste_date", datetime.utcnow()),
        )
        db.add(waste_log)
        
    else:
        item_id = data.get("item_id")
        if not item_id:
            raise ValueError("Item ID is required for inventory waste")
        
        item = get_item_by_id(db, item_id)
        if not item:
            raise ValueError("Item not found")
        
        if item.current_stock < data["quantity"]:
            raise ValueError(f"Insufficient stock for {item.name}. Available: {item.current_stock}, Reported: {data['quantity']}")
        
        log_number = generate_waste_log_number(db)
        waste_log = WasteLog(
            log_number=log_number,
            item_id=item_id,
            is_food_item=False,
            location_id=data.get("location_id"),
            batch_number=data.get("batch_number"),
            expiry_date=data.get("expiry_date"),
            quantity=data["quantity"],
            unit=data["unit"],
            reason_code=data["reason_code"],
            action_taken=data.get("action_taken"),
            photo_path=data.get("photo_path"),
            notes=data.get("notes"),
            reported_by=reported_by,
            waste_date=data.get("waste_date", datetime.utcnow()),
        )
        db.add(waste_log)
        
        item.current_stock -= data["quantity"]
        
        # Deduct from Location Stock if location is specified
        if data.get("location_id"):
            from app.models.inventory import LocationStock, AssetMapping, AssetRegistry
            
            # 1. Try Deducting from Location Stock
            loc_stock = db.query(LocationStock).filter(
                LocationStock.location_id == data["location_id"],
                LocationStock.item_id == item_id
            ).first()
            if loc_stock:
                loc_stock.quantity -= data["quantity"]
                loc_stock.last_updated = datetime.utcnow()
            
            # 2. Try Deducting from Asset Mappings (e.g. "light" in Room 101)
            # This is likely where the user's issue lies if it's an asset
            mappings = db.query(AssetMapping).filter(
                AssetMapping.location_id == data["location_id"],
                AssetMapping.item_id == item_id,
                AssetMapping.is_active == True
            ).all()
            
            qty_to_remove = data["quantity"]
            for mapping in mappings:
                if qty_to_remove <= 0:
                    break
                available = mapping.quantity or 1
                if available > qty_to_remove:
                    mapping.quantity = available - qty_to_remove
                    qty_to_remove = 0
                else:
                    # Remove entire mapping or mark inactive
                    mapping.is_active = False # Soft delete or remove
                    # db.delete(mapping) # Or hard delete
                    qty_to_remove -= available

            # 3. Try Removing from Asset Registry (Specific tagged assets)
            if qty_to_remove > 0:
                # If we still have quantity to remove, maybe they are tracked individual items?
                registry_items = db.query(AssetRegistry).filter(
                    AssetRegistry.current_location_id == data["location_id"],
                    AssetRegistry.item_id == item_id,
                    AssetRegistry.status == "active"
                ).limit(int(qty_to_remove)).all()
                
                for asset in registry_items:
                    asset.status = "written_off" # Or damaged/disposed
                    asset.notes = (asset.notes or "") + f" [Waste Log: {log_number}]"
        
        transaction = InventoryTransaction(
            item_id=item_id,
            transaction_type="out",
            quantity=data["quantity"],
            unit_price=item.unit_price,
            total_amount=item.unit_price * data["quantity"] if item.unit_price else None,
            reference_number=log_number,
            notes=f"Waste/Spoilage: {data['reason_code']} - {data.get('notes', '')}",
            created_by=reported_by
        )
        if transaction.total_amount and transaction.total_amount > 0:
            try:
                from app.utils.accounting_helpers import create_consumption_journal_entry
                create_consumption_journal_entry(
                    db=db,
                    consumption_id=waste_log.id,
                    cogs_amount=float(transaction.total_amount),
                    inventory_item_name=item.name,
                    created_by=reported_by,
                    reference_type="waste"
                )
            except Exception as e:
                print(f"Failed to create accounting entry for waste: {e}")
        
        db.add(transaction)
    
    db.commit()
    db.refresh(waste_log)
    return waste_log


def get_all_waste_logs(db: Session, skip: int = 0, limit: int = 100):
    from app.models.inventory import WasteLog
    return db.query(WasteLog).order_by(WasteLog.created_at.desc()).offset(skip).limit(limit).all()


def get_waste_log_by_id(db: Session, waste_log_id: int):
    from app.models.inventory import WasteLog
    return db.query(WasteLog).filter(WasteLog.id == waste_log_id).first()


# Location CRUD
def generate_location_code(db: Session, location_type: str, room_area: str):
    """Generate location code like LOC-RM-101"""
    prefix_map = {
        "GUEST_ROOM": "RM",
        "Guest Room": "RM",
        "WAREHOUSE": "WH",
        "CENTRAL_WAREHOUSE": "WH",
        "BRANCH_STORE": "BS",
        "SUB_STORE": "SS",
        "DEPARTMENT": "DEPT",
        "PUBLIC_AREA": "PA",
        "Public Area": "PA",
        "LAUNDRY": "LNDRY",
        "Laundry": "LNDRY"
    }
    prefix = prefix_map.get(location_type, "LOC")
    
    # Extract numbers from room_area if available
    import re
    numbers = re.findall(r'\d+', room_area)
    
    if numbers:
        base_suffix = numbers[0]
        code = f"LOC-{prefix}-{base_suffix}"
        # Check existence
        if not db.query(Location).filter(Location.location_code == code).first():
            return code
        # If exists with number, append 'A', 'B' etc? Or just fallback to count.
        # Let's fallback to incremental if specific number logic fails or is taken.
    
    # Generic incremental fallback
    count = db.query(Location).count() + 1
    while True:
        code = f"LOC-{prefix}-{count}"
        if not db.query(Location).filter(Location.location_code == code).first():
            return code
        count += 1


def create_location(db: Session, data: dict):
    from app.models.inventory import Location
    location_code = generate_location_code(db, data.get("location_type", ""), data.get("room_area", ""))
    location = Location(
        location_code=location_code,
        **data
    )
    db.add(location)
    db.commit()
    db.refresh(location)
    return location


def get_all_locations(db: Session, skip: int = 0, limit: int = 10000):  # Increased limit to show all rooms
    from app.models.inventory import Location
    # Skip auto-sync here - it's handled in the API endpoint to avoid transaction conflicts
    # Just return locations directly
    return db.query(Location).filter(Location.is_active == True).offset(skip).limit(limit).all()


def get_location_by_id(db: Session, location_id: int):
    from app.models.inventory import Location
    return db.query(Location).filter(Location.id == location_id).first()


def update_location(db: Session, location_id: int, data: dict):
    from app.models.inventory import Location
    location = get_location_by_id(db, location_id)
    if not location:
        return None
    for key, value in data.items():
        setattr(location, key, value)
    db.commit()
    db.refresh(location)
    return location


# Asset Mapping CRUD
def create_asset_mapping(db: Session, data: dict, assigned_by: Optional[int] = None):
    from app.models.inventory import AssetMapping, InventoryItem, LocationStock
    from datetime import datetime
    
    item_id = data["item_id"]
    quantity = data.get("quantity", 1.0)
    
    # 1. Get Item (No stock check - allow negative stock to track deficits)
    item = get_item_by_id(db, item_id)
    if not item:
        raise ValueError("Item not found")
    
    # Allow assignment even with insufficient stock - will create negative stock if needed
    # This helps track deficits and maintains transaction history
        
    # 2. Create Mapping
    mapping = AssetMapping(
        item_id=item_id,
        location_id=data["location_id"],
        serial_number=data.get("serial_number"),
        notes=data.get("notes"),
        assigned_by=assigned_by,
        quantity=quantity
    )
    db.add(mapping)
    
    # 3. Deduct from Source Location Stock (e.g. Warehouse)
    # Do NOT deduct from item.current_stock (Global), as that represents Total Assets Owned.
    # Only deduct from the specific LocationStock where the item is physically moving from.
    
    # Assume source is Central Warehouse (ID 1) strictly for now as per current flow
    # Future improvement: Pass source_location_id in data
    # FIX: Find warehouse dynamically instead of hardcoding ID 1
    from app.models.inventory import LocationStock, InventoryTransaction, Location
    
    source_loc_id = data.get("source_location_id")
    
    if not source_loc_id:
        warehouse = db.query(Location).filter(
            Location.location_type.in_(["WAREHOUSE", "CENTRAL_WAREHOUSE"])
        ).first()
        
        if not warehouse:
            warehouse = db.query(Location).filter(
                Location.location_type.ilike("%warehouse%")
            ).first()
        
        if not warehouse:
            raise ValueError("No warehouse location found. Please create a warehouse location first.")
        
        source_loc_id = warehouse.id
    

    source_stock = db.query(LocationStock).filter(
        LocationStock.location_id == source_loc_id,
        LocationStock.item_id == item_id
    ).first()
    
    if source_stock:
        if source_stock.quantity >= quantity:
            source_stock.quantity -= quantity
            source_stock.last_updated = datetime.utcnow()
        else:
             # Force deduction to keep sync with global stock, even if it goes negative (should have been checked)
             source_stock.quantity -= quantity
             
    # 3.2 Create Stock Issue (Transfer Record)
    # This ensures it shows up in history for both Source and Destination
    from app.models.inventory import StockIssue, StockIssueDetail
    
    # Generate Issue Number
    from app.curd.inventory import generate_issue_number
    issue_number = generate_issue_number(db)
    
    # Fetch Dest Location Name
    dest_loc = db.query(Location).filter(Location.id == data["location_id"]).first()
    dest_name = dest_loc.name if dest_loc else "Unknown Location"

    stock_issue = StockIssue(
        issue_number=issue_number,
        issued_by=assigned_by,
        source_location_id=source_loc_id,
        destination_location_id=data["location_id"],
        issue_date=datetime.utcnow(),
        notes=f"Auto-generated from Asset Assignment to {dest_name}"
    )
    db.add(stock_issue)
    db.flush() # Get ID
    
    issue_detail = StockIssueDetail(
        issue_id=stock_issue.id,
        item_id=item_id,
        issued_quantity=quantity,
        unit=item.unit,
        unit_price=item.unit_price,
        cost=(item.unit_price or 0) * quantity,
        notes=f"Asset Mapping ID: {mapping.id}"
    )
    db.add(issue_detail)

    # 3.3 Create Transaction Record (Linked to Issue)
    transaction = InventoryTransaction(
        item_id=item_id,
        transaction_type="transfer_out", # snake_case matches frontend logic
        quantity=quantity,
        unit_price=item.unit_price,
        total_amount=item.unit_price * quantity if item.unit_price else 0,
        reference_number=issue_number, # Link to Stock Issue
        notes=f"Asset Assigned to {dest_name}",
        created_by=assigned_by
    )
    db.add(transaction)
    
    # 3.4 Create Paired "Transfer In" Transaction (Stock Received at Dest)
    transaction_in = InventoryTransaction(
        item_id=item_id,
        transaction_type="transfer_in",
        quantity=quantity,
        unit_price=item.unit_price,
        total_amount=item.unit_price * quantity if item.unit_price else 0,
        reference_number=issue_number,
        department=dest_name, # Critical for frontend to show "To Location"
        notes=f"Asset Received from Central Warehouse",
        created_by=assigned_by
    )
    db.add(transaction_in)
    
    # 4. Add to Destination Location Stock
    loc_stock = db.query(LocationStock).filter(
        LocationStock.location_id == data["location_id"],
        LocationStock.item_id == item_id
    ).first()
    
    if loc_stock:
        loc_stock.quantity += quantity
        loc_stock.last_updated = datetime.utcnow()
    else:
        new_stock = LocationStock(
            location_id=data["location_id"],
            item_id=item_id,
            quantity=quantity,
            last_updated=datetime.utcnow()
        )
        db.add(new_stock)
    
    db.commit()
    db.refresh(mapping)
    return mapping


def get_all_asset_mappings(db: Session, skip: int = 0, limit: int = 100, location_id: Optional[int] = None):
    from app.models.inventory import AssetMapping
    query = db.query(AssetMapping).filter(AssetMapping.is_active == True)
    if location_id:
        query = query.filter(AssetMapping.location_id == location_id)
    return query.order_by(AssetMapping.assigned_date.desc()).offset(skip).limit(limit).all()


def get_asset_mapping_by_id(db: Session, mapping_id: int):
    from app.models.inventory import AssetMapping
    # Return directly, assuming controller handles 404
    return db.query(AssetMapping).filter(AssetMapping.id == mapping_id).first()


def update_asset_mapping(db: Session, mapping_id: int, data: dict):
    from app.models.inventory import AssetMapping, Location, LocationStock
    from datetime import datetime
    mapping = get_asset_mapping_by_id(db, mapping_id)
    if not mapping:
        return None
    
    # Check if unassigning (is_active -> False)
    if "is_active" in data and data["is_active"] is False and mapping.is_active:
        # Transfer stock BACK to Warehouse (Location -> Warehouse)
        warehouse = db.query(Location).filter(
            Location.location_type.in_(["WAREHOUSE", "CENTRAL_WAREHOUSE"])
        ).first()
        
        if warehouse:
            qty = mapping.quantity
            
            # 1. Deduct from Target Location
            target_stock = db.query(LocationStock).filter(
                LocationStock.location_id == mapping.location_id,
                LocationStock.item_id == mapping.item_id
            ).first()
            
            if target_stock:
                target_stock.quantity -= qty
                target_stock.last_updated = datetime.utcnow()
                
            # 2. Add back to Warehouse
            wh_stock = db.query(LocationStock).filter(
                LocationStock.location_id == warehouse.id,
                LocationStock.item_id == mapping.item_id
            ).first()
            
            if wh_stock:
                wh_stock.quantity += qty
                wh_stock.last_updated = datetime.utcnow()
            else:
                wh_stock = LocationStock(
                    location_id=warehouse.id,
                    item_id=mapping.item_id,
                    quantity=qty,
                    last_updated=datetime.utcnow()
                )
                db.add(wh_stock)

    # Update allowed fields
    for field in ["location_id", "serial_number", "quantity", "notes", "is_active"]:
        if field in data and data[field] is not None:
             setattr(mapping, field, data[field])
             
    db.commit()
    db.refresh(mapping)
    return mapping


def unassign_asset(db: Session, mapping_id: int, destination_location_id: int = None):
    from app.models.inventory import AssetMapping, Location, LocationStock
    from datetime import datetime
    
    mapping = get_asset_mapping_by_id(db, mapping_id)
    if not mapping:
        return None
        
    if mapping.is_active:
        mapping.is_active = False
        mapping.unassigned_date = datetime.utcnow()
        
        # Return stock to Warehouse/Available
        # 1. Deduct from Location
        loc_stock = db.query(LocationStock).filter(
            LocationStock.location_id == mapping.location_id,
            LocationStock.item_id == mapping.item_id
        ).first()
        
        if loc_stock:
            loc_stock.quantity = max(0, loc_stock.quantity - mapping.quantity)
            loc_stock.last_updated = datetime.utcnow()
            
        # 2. Add back to Warehouse (Physical Location)
        # Find warehouse to return to
        warehouse = None
        if destination_location_id:
             warehouse = db.query(Location).filter(Location.id == destination_location_id).first()

        if not warehouse:
            # Fallback to default logic
            warehouse = db.query(Location).filter(
                Location.location_type.in_(["WAREHOUSE", "CENTRAL_WAREHOUSE"])
            ).first()
        
        if not warehouse:
             warehouse = db.query(Location).filter(
                Location.location_type.ilike("%warehouse%")
            ).first()
            
        if warehouse:
            wh_stock = db.query(LocationStock).filter(
                LocationStock.location_id == warehouse.id,
                LocationStock.item_id == mapping.item_id
            ).first()
            
            if wh_stock:
                wh_stock.quantity += mapping.quantity
                wh_stock.last_updated = datetime.utcnow()
            else:
                wh_stock = LocationStock(
                    location_id=warehouse.id,
                    item_id=mapping.item_id,
                    quantity=mapping.quantity,
                    last_updated=datetime.utcnow()
                )
                db.add(wh_stock)
        else:
             print("Warning: No warehouse found to return unassigned asset stock to.")

        # Note: Global stock (item.current_stock) should NOT change because the item 
        # is just moving from Room -> Warehouse. It is still owned.
        # But if the previous logic was incrementing global stock, it was wrong because 
        # unassigning doesn't mean "New Purchase", it means "Return to Shelf".
        # So we do NOTHING to item.current_stock.
            
    db.commit()
    db.refresh(mapping)
    return mapping


# Asset Registry CRUD
def generate_asset_tag_id(db: Session, item_id: int):
    """Generate asset tag ID like AST-TV-014"""
    from app.models.inventory import AssetRegistry, InventoryItem
    item = db.query(InventoryItem).filter(InventoryItem.id == item_id).first()
    item_prefix = item.name[:2].upper() if item else "AST"
    count = db.query(AssetRegistry).filter(AssetRegistry.item_id == item_id).count() + 1
    return f"AST-{item_prefix}-{str(count).zfill(3)}"


def create_asset_registry(db: Session, data: dict, created_by: int = None):
    from app.models.inventory import AssetRegistry, LocationStock, Location, InventoryTransaction, PurchaseMaster
    
    # 1. Determine Source Location (Automatic Detection)
    source_loc_id = None
    
    # Strategy A: Check Purchase Master
    if data.get("purchase_master_id"):
        purchase = db.query(PurchaseMaster).filter(PurchaseMaster.id == data["purchase_master_id"]).first()
        if purchase and purchase.destination_location_id:
            source_loc_id = purchase.destination_location_id
    
    # Strategy B: Check Item's default string location
    if not source_loc_id:
        item = get_item_by_id(db, data["item_id"])
        if item and item.location:
             # Try to map string to ID
             # This is a basic lookup. can be optimized with a pre-fetched map if needed
             loc = db.query(Location).filter(Location.name.ilike(item.location.strip())).first()
             if loc:
                 source_loc_id = loc.id
    
    # Strategy C: Default to Central Warehouse if nothing else found
    if not source_loc_id:
        # Find warehouse dynamically instead of hardcoding ID 1
        warehouse = db.query(Location).filter(
            Location.location_type.in_(["WAREHOUSE", "CENTRAL_WAREHOUSE"])
        ).first()
        
        if not warehouse:
            warehouse = db.query(Location).filter(
                Location.location_type.ilike("%warehouse%")
            ).first()
        
        if warehouse:
            source_loc_id = warehouse.id
            
    # 2. Deduct from Source Stock
    if source_loc_id:
        stock = db.query(LocationStock).filter(
            LocationStock.location_id == source_loc_id,
            LocationStock.item_id == data["item_id"]
        ).first()
        
        if stock:
            if stock.quantity >= 1:
                stock.quantity -= 1
            else:
                # Stock is 0 or negative. Still deduct? User wants "reduced from source".
                # Let's allow it to go negative or stay 0 based on policy. 
                # Usually better to decrement to track deficit.
                stock.quantity -= 1
        else:
            # Create negative stock entry if it doesn't exist? 
            # Or assume it wasn't tracked. Let's create it to be safe/explicit.
            new_stock = LocationStock(
                location_id=source_loc_id,
                item_id=data["item_id"],
                quantity=-1
            )
            db.add(new_stock)
            
    # 3. Create Asset
    asset_tag_id = generate_asset_tag_id(db, data["item_id"])
    asset = AssetRegistry(
        asset_tag_id=asset_tag_id,
        item_id=data["item_id"],
        serial_number=data.get("serial_number"),
        current_location_id=data["current_location_id"],
        status=data.get("status", "active"),
        purchase_date=data.get("purchase_date"),
        warranty_expiry_date=data.get("warranty_expiry_date"),
        last_maintenance_date=data.get("last_maintenance_date"),
        next_maintenance_due_date=data.get("next_maintenance_due_date"),
        purchase_master_id=data.get("purchase_master_id"),
        notes=data.get("notes")
    )
    db.add(asset)
    
    # 4. Create Transaction
    # Get names for notes
    source_name = "Unknown Source"
    if source_loc_id:
        src = db.query(Location).filter(Location.id == source_loc_id).first()
        if src: source_name = src.name
        
    dest_name = "Unknown Destination"
    if data.get("current_location_id"):
        dst = db.query(Location).filter(Location.id == data["current_location_id"]).first()
        if dst: dest_name = dst.name

    transaction = InventoryTransaction(
        item_id=data["item_id"],
        transaction_type="Transfer Out", # Matching frontend filter
        quantity=1,
        # unit_price=?, FIXME: Need item price
        reference_number=asset_tag_id,
        notes=f"Asset Assigned: {source_name} -> {dest_name}",
        created_by=created_by
    )
    # Fetch item for price
    item_obj = get_item_by_id(db, data["item_id"])
    if item_obj:
        transaction.unit_price = item_obj.unit_price
        transaction.total_amount = item_obj.unit_price * 1
        
    db.add(transaction)

    db.commit()
    db.refresh(asset)
    return asset


def get_all_asset_registry(db: Session, skip: int = 0, limit: int = 100, location_id: Optional[int] = None, status: Optional[str] = None):
    from app.models.inventory import AssetRegistry
    query = db.query(AssetRegistry)
    if location_id:
        query = query.filter(AssetRegistry.current_location_id == location_id)
    if status:
        query = query.filter(AssetRegistry.status == status)
    return query.order_by(AssetRegistry.created_at.desc()).offset(skip).limit(limit).all()


def get_asset_registry_by_id(db: Session, asset_id: int):
    from app.models.inventory import AssetRegistry
    return db.query(AssetRegistry).filter(AssetRegistry.id == asset_id).first()


def update_asset_registry(db: Session, asset_id: int, data: dict):
    from app.models.inventory import AssetRegistry
    asset = get_asset_registry_by_id(db, asset_id)
    if not asset:
        return None
    for key, value in data.items():
        setattr(asset, key, value)
    db.commit()
    db.refresh(asset)
    return asset


def delete_asset_registry(db: Session, asset_id: int):
    from app.models.inventory import AssetRegistry
    asset = get_asset_registry_by_id(db, asset_id)
    if not asset:
        return None
    db.delete(asset)
    db.commit()
    return asset





def get_all_stock_requisitions(db: Session, skip: int = 0, limit: int = 100, status: Optional[str] = None):
    query = db.query(StockRequisition).options(
        joinedload(StockRequisition.details).joinedload(StockRequisitionDetail.item),
        joinedload(StockRequisition.requester)
    )
    if status:
        query = query.filter(StockRequisition.status == status)
    return query.order_by(StockRequisition.created_at.desc()).offset(skip).limit(limit).all()


def get_stock_requisition_by_id(db: Session, requisition_id: int):
    return db.query(StockRequisition).options(
        joinedload(StockRequisition.details).joinedload(StockRequisitionDetail.item),
        joinedload(StockRequisition.requester)
    ).filter(StockRequisition.id == requisition_id).first()


def update_stock_requisition_status(db: Session, requisition_id: int, status: str, approved_by_id: Optional[int] = None):
    requisition = get_stock_requisition_by_id(db, requisition_id)
    if not requisition:
        return None
    
    requisition.status = status
    if status == "approved" and approved_by_id:
        requisition.approved_by = approved_by_id
        requisition.approved_at = datetime.utcnow()
    
    db.commit()
    db.refresh(requisition)
    return requisition


# Stock Issue CRUD

def get_all_stock_issues(db: Session, skip: int = 0, limit: int = 100):
    return db.query(StockIssue).options(
        joinedload(StockIssue.details).joinedload(StockIssueDetail.item),
        joinedload(StockIssue.source_location),
        joinedload(StockIssue.destination_location),
        joinedload(StockIssue.issuer)
    ).order_by(StockIssue.created_at.desc()).offset(skip).limit(limit).all()


def process_food_order_usage(db: Session, order_id: int):
    """
    Deduct inventory stock based on food order items and their recipes.
    Should be called when order status changes to 'completed'.
    """
    from app.models.foodorder import FoodOrder
    from app.models.recipe import Recipe
    
    order = db.query(FoodOrder).filter(FoodOrder.id == order_id).first()
    if not order or not order.items:
        return
    
    # Group total ingredient usage across all items in the order
    ingredient_usage = {} # item_id -> quantity
    
    for order_item in order.items:
        # Find recipe for this food item
        recipe = db.query(Recipe).filter(Recipe.food_item_id == order_item.food_item_id).first()
        
        if recipe and recipe.ingredients:
            servings = recipe.servings or 1
            multiplier = order_item.quantity / servings
            
            for ingredient in recipe.ingredients:
                qty_needed = ingredient.quantity * multiplier
                
                if ingredient.inventory_item_id in ingredient_usage:
                    ingredient_usage[ingredient.inventory_item_id] += qty_needed
                else:
                    ingredient_usage[ingredient.inventory_item_id] = qty_needed
    
    # Find Kitchen/Consumption Location
    # Strategy:
    # 1. Look for a location named "Main Kitchen" or containing "Kitchen" (preferred).
    # 2. Look for a location matching the item's category parent_department (e.g. "Restaurant").
    
    from app.models.inventory import Location, LocationStock
    
    kitchen_loc = db.query(Location).filter(
        Location.name.ilike("%Main Kitchen%"),
        Location.is_active == True
    ).first()
    
    if not kitchen_loc:
        # Fallback to any kitchen
        kitchen_loc = db.query(Location).filter(
            Location.name.ilike("%Kitchen%"),
            Location.is_active == True
        ).first()

    # Deduct stock and create transactions
    for item_id, quantity in ingredient_usage.items():
        item = get_item_by_id(db, item_id)
        if not item:
            continue
            
        # 1. Deduct Global Stock (Total Assets Owned)
        current = item.current_stock or 0.0
        item.current_stock = current - quantity
        
        # 2. Deduct Location Stock (Physical consumption from Kitchen)
        if kitchen_loc:
             loc_stock = db.query(LocationStock).filter(
                 LocationStock.location_id == kitchen_loc.id,
                 LocationStock.item_id == item_id
             ).first()
             
             if loc_stock:
                 loc_stock.quantity -= quantity
                 loc_stock.last_updated = datetime.utcnow()
             else:
                 # Create negative stock to track deficit/usage if not transferred yet
                 new_stock = LocationStock(
                     location_id=kitchen_loc.id,
                     item_id=item_id,
                     quantity=-quantity,
                     last_updated=datetime.utcnow()
                 )
                 db.add(new_stock)

        # Create transaction
        transaction = InventoryTransaction(
            item_id=item_id,
            transaction_type="out", # Standard consumption
            quantity=quantity,
            unit_price=item.unit_price,
            total_amount=item.unit_price * quantity if item.unit_price else None,
            reference_number=f"ORD-{order_id}",
            department=item.category.parent_department if item.category else "Restaurant",
            notes=f"Food Order #{order_id} Consumption from {kitchen_loc.name if kitchen_loc else 'Global Stock'}",
            created_by=None 
        )
        db.add(transaction)
    
    # db.commit() removed to allow atomic transaction in caller


def get_location_stock(db: Session, location_id: int):
    """Get all items available at a specific location"""
    from app.models.inventory import LocationStock, InventoryItem, Location
    
    # Get the location object to get its name
    location = db.query(Location).filter(Location.id == location_id).first()
    if not location:
        return []
    
    # Query LocationStock table (new system)
    stocks = db.query(LocationStock).options(
        joinedload(LocationStock.item).joinedload(InventoryItem.category)
    ).filter(
        LocationStock.location_id == location_id,
        LocationStock.quantity != 0 
    ).all()
    
    result = []
    item_ids_seen = set()
    
    # Add items from LocationStock table
    for s in stocks:
        if not s.item: continue
        item_ids_seen.add(s.item_id)
        result.append({
            "item_id": s.item_id,
            "item_name": s.item.name,
            "quantity": float(s.quantity),
            "unit": s.item.unit,
            "category_name": s.item.category.name if s.item.category else None,
            "min_stock_level": float(s.item.min_stock_level or 0),
            "is_low_stock": float(s.quantity) <= (s.item.min_stock_level or 0),
            "unit_price": float(s.item.unit_price or 0)
        })
    
    # FALLBACK: Also check InventoryItem.location field (legacy system)
    # This handles items that were created with location as a text field
    legacy_items = db.query(InventoryItem).options(
        joinedload(InventoryItem.category)
    ).filter(
        InventoryItem.location.ilike(f"%{location.name}%"),
        InventoryItem.current_stock > 0,
        InventoryItem.is_active == True
    ).all()
    
    for item in legacy_items:
        if item.id in item_ids_seen:
            continue  # Already added from LocationStock
        result.append({
            "item_id": item.id,
            "item_name": item.name,
            "quantity": float(item.current_stock or 0),
            "unit": item.unit,
            "category_name": item.category.name if item.category else None,
            "min_stock_level": float(item.min_stock_level or 0),
            "is_low_stock": float(item.current_stock or 0) <= (item.min_stock_level or 0),
            "unit_price": float(item.unit_price or 0)
        })
    
    return result


def get_all_recipes(db: Session, skip: int = 0, limit: int = 100):
   """Get all recipes"""
   from app.models.recipe import Recipe, RecipeIngredient
   return db.query(Recipe).options(
       joinedload(Recipe.food_item),
       selectinload(Recipe.ingredients).joinedload(RecipeIngredient.inventory_item)
   ).offset(skip).limit(limit).all()
